Step 1 - Load the netbeans IDE
Step 2 - Load the project into netbeans
Step 3 - Run the JFLogin.java file in the unisystemsGUI/source Packages/unisystems.gui
Step 4 - Load the data file testdata.data in the uploaded file
Step 5 - Log in details are for the super user are username - "superuser" and password - "password"
Step 6 - The username for the normal user is username - "1" and Password - "Academic1!"
Step 7 - To save the file open the file tab in the top left and select save. Alternatively use Ctrl+S
Step 8 - Select a file or enter a file name to save the data to that file.

The UML diagram is created using netbeans plugun easy UML. The plugin download can be downloaded from http://plugins.netbeans.org/plugin/55435/easyuml.
You can also find it in the update center. The UML folder can be loaded into netbeans as a project for viewing.
please use this addon to see the final UML, as it's was abit large for a screenshot.

You may now safely close the program
